package argo.jdom;

import java.util.List;

final class JsonObject extends AbstractJsonObject {
	
	@Override
	public String getText() {
		return null;
	}
	
	@Override
	public List<JsonField> getFieldList() {
		return null;
	}
	
}

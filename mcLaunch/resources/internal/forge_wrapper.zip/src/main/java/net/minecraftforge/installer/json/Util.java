package net.minecraftforge.installer.json;

public class Util {
	
	public static InstallV1 loadInstallProfile() {
		return null;
	}
	
}

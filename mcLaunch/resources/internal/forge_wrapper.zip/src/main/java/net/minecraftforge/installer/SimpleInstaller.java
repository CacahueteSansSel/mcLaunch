package net.minecraftforge.installer;

public class SimpleInstaller {
	
	public static boolean headless = false;
	
}

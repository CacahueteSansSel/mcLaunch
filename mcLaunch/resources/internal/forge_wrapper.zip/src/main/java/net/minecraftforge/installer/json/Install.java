package net.minecraftforge.installer.json;

public class Install {
	protected String version;
}
